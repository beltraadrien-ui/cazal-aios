---
name: rapport-performance
description: Analyse les posts de Loïc depuis Supabase (vues, engagement, hooks, sujets, formats, durées) et produit un rapport de ce qui marche vs ce qui sous-performe, puis régénère le digest bundlé pour le mobile. Skill MOTEUR (Claude Code, engine). Se déclenche sur "rapport de performance", "analyse mes posts", "qu'est-ce qui marche dans mon contenu".
---

# Rapport de performance — Cazal Réfrigération (MOTEUR)

## Ce que fait cette skill

Lit la vue Supabase **`contenu_avec_scores`** (posts de Loïc) et produit un rapport de ce qui marche
vs ce qui sous-performe : hooks, sujets, formats, durées. Sa sortie nourrit la section **À EXPLOITER /
À RÉ-ANGLER** de `references/rapport-perf-digest.md` (snapshot bundlé lu par les skills mobiles).

> ⚙️ Skill engine (Claude Code, Supabase). Au démarrage Loïc a peu de data → c'est `rapport-concurrents`
> qui porte l'analyse ; sa propre data prend le relais à mesure qu'elle s'accumule.

## Métriques (calculées côté Supabase par la vue)
- **`calc_outlier_score`** = vues ÷ moyenne du compte. **Outlier** = catégorie `hit` (≥2×) / `viral` (≥5×).
- **`calc_engagement_rate`** = (likes+comments+shares+saves) ÷ vues × 100.
- Compléter avec la **médiane** des vues (la vue donne aussi les vues brutes).

## Étapes
1. Récupérer les posts de Loïc :
   ```bash
   python shared/scripts/search/list_contenu_scores.py --type own --limit 200
   ```
   (lecture de `contenu_avec_scores` filtrée sur les comptes `type=own`).
2. Analyser le JSON : vue d'ensemble (nb, moyenne/médiane/max, taux d'outliers), top performers
   (+ hypothèse de la variable gagnante), sous-performers (+ piste de ré-angle), puis par dimension
   (hook_structure / topic / visual_format / durée).
3. Écrire le rapport daté dans `active/analyse/rapport-performance-AAAA-MM-JJ.md`.
4. **Régénérer** `references/rapport-perf-digest.md` (sections À EXPLOITER / À RÉ-ANGLER), court et
   actionnable (1-3 p.). Puis rappeler de re-zipper/re-uploader les skills (export_skills.py).

## Règles fermes
- **Distinguer ré-utilisable vs jetable** : hook « bénéfice reproductible » → se reposte ; hook
  « émotion one-shot / actu » → ne pas resservir tel quel. Le marquer dans le digest.
- Ne rien inventer : pas assez de données → le dire (« échantillon insuffisant → s'appuyer sur les concurrents »).
- Digest court (bundlé en mobile).
